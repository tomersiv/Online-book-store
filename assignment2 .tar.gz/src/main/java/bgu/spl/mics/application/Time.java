package bgu.spl.mics.application;

public class Time {
    private int speed;
    private int duration;

    public int getSpeed() {
        return speed;
    }

    public int getDuration() {
        return duration;
    }
}
