package bgu.spl.mics.application;

import bgu.spl.mics.application.passiveObjects.DeliveryVehicle;

public class Resources {
    private DeliveryVehicle[] vehicles;

    public DeliveryVehicle[] getVehicles() {
        return vehicles;
    }
}

